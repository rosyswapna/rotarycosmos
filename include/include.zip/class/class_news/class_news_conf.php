<?php

define("NEWS_DIR","images/news/");

?>
