<?php
define("ADMIN_TYPE", 1);
?>
