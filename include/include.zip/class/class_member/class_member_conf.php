<?php

define("MEMBER_DIR","images/user/");

?>
