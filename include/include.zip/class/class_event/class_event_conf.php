<?php

define("EVENT_DIR","images/event/");

?>
