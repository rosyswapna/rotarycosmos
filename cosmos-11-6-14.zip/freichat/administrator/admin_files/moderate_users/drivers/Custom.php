<?php

require 'base.php';

class Custom extends Moderation {
}
