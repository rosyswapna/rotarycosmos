
.div_center_login{
width:300px;
margin-top:10%;
margin-bottom:auto;
margin-left:auto;
margin-right:auto;
}
