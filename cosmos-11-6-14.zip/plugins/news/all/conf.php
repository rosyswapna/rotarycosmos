<?php
  // prevent execution of this code by direct call from browser
  if ( !defined('CHECK_INCLUDED') ){
    exit();
  }

$MSG_mesg = "No Records Found ";

$MSG_empty_search_string = "search_string Empty ";


$RD_MSG_attempt_failed = "Attempt Failed";



$CAP_page_caption = "News";

$CAP_search_string = "Search";
$CAP_name = "News";
$CAP_status = "Status";

$CAP_submit = "Search";



?>
