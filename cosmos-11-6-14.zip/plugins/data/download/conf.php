<?php

define("DOWNLOAD_DIR","files/download/");
$conf_page_caption = "Download Error...";


?>
