<?php
  // prevent execution of this code by direct call from browser
  if ( !defined('CHECK_INCLUDED') ){
    exit();
  }

$MSG_mesg = "No Records Found ";

$MSG_empty_username = "Username Empty ";


$RD_MSG_attempt_failed = "Attempt Failed";



$CAP_page_caption = "Members";

$CAP_username = "UserName";
$CAP_userstatus = "User Status";
$CAP_clubposition = "Club Position";
$CAP_emailid = "Email";

$CAP_submit = "Search";



?>
