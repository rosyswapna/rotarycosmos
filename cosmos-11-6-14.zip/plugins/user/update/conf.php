<?php

$MSG_empty_username = "Username Empty ";
$MSG_invalid_username = "Username is not a valid E-mail Address";

$MSG_empty_email = "Email Empty ";

$MSG_invalid_email = "email is not a valid E-mail Address";

$MSG_empty_password = "Password Empty";

$MSG_empty_retype_password = "Retype Password Empty ";

$MSG_unmatching_passwords = "Unmatching Passwords";

$MSG_length_password = "Password Contain unwanted Characters or below 5 Characters ";

$MSG_empty_userstatus = "Userstatus Empty ";
$MSG_empty_clubposition = "ClubPosition Empty ";

$MSG_empty_question = "Security Question Empty ";

$MSG_empty_answer = "Answer Empty ";


$RD_MSG_deleted = "Member Deleted";

$RD_MSG_updated = "Member Updated";

$RD_MSG_attempt_failed = "Attempt Failed";

$RD_MSG_added = "Member added";



$CAP_page_caption_add = "Add Member";

$CAP_page_caption_update = "Update Member";

$CAP_username = "Username (Email)";

$CAP_email = "Email";

$CAP_password = "Password";

$CAP_repassword = "Retype Password";

$CAP_userstatus = "Userstatus";
$CAP_clubposition = "Club Position";

$CAP_question = "Security Question";

$CAP_answer = "Security Answer";

$CAP_add = "Add Member";

$CAP_update = "Update Member";

$CAP_delete = "Delete Member";


?>
