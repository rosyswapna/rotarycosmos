<?php


$MSG_length_password = "Password Contain unwanted Characters or below 5 Characters ";

$MSG_empty_password = "Password Empty ";

$MSG_empty_new_password = "New Password Empty ";

$MSG_empty_retype_password = "Retype Password Empty ";

$MSG_unmatching_passwords = "Unmatching Passwords";

$RD_MSG_incorrect_password  = "Password seems to be incorrect";

$RD_MSG_changed_password  = "Password Updated";

$CAP_page_caption = "ChangePassword";

$CAP_password = "Current Password";

$CAP_new_password = "New Password";

$CAP_retype_password = "Retype Password";

$CAP_change = "Change";

?>
