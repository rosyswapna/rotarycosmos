<?php
  // prevent execution of this code by direct call from browser
  if ( !defined('CHECK_INCLUDED') ){
    exit();
  }

$MSG_mesg = "No Records Found ";

$MSG_empty_username = "Username Empty ";


$RD_MSG_attempt_failed = "Attempt Failed";



$CAP_page_caption = "Member Logged In ";

$CAP_username = "UserName";
$CAP_name = "Name";
$CAP_date = "Logged-In Date";
$CAP_ip = "IP";



?>
