<?php

$MSG_empty_username = "Email Empty ";
$MSG_invalid_email = "Invalid E-mail Address";
$MSG_empty_first_name = "First Name Empty ";
$MSG_empty_last_name = "Last Name Empty ";
$MSG_empty_district_number = "District Number Empty ";
$MSG_empty_club_name = "Club Name Empty ";
$MSG_empty_president_emailid = "President Email Empty ";
$MSG_empty_secretary_emailid = "Secretary Email Empty ";

$MSG_invalid_security_code = "Sorry, you have provided an invalid security code";
$MSG_empty_security_code = "security code cannot be empty";


$CAP_page_caption = "Guest :: Signup";

$CAP_username = "Email";
$CAP_first_name = "First Name";
$CAP_last_name = "Last Name";
$CAP_district_number = "District Number";
$CAP_club_name = "Club Name";
$CAP_president_emailid = "President Email";
$CAP_secretary_emailid = "Secretary Email";


$CAP_security_code = "Security Code";
$CAP_security_code_message = "Type the security code you see in the image on above text box.";

$CAP_add = "Signup";


$RD_MSG_attempt_failed = "Unable to signup. Please Contact System Administrator";

$RD_MSG_signup = "Check your mail to confirm registration";

?>
