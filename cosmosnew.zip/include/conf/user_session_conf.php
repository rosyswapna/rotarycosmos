<?php

$msg_default_username = "Enter your User Name ";

$submit_sign_in = "Sign In";


?>
