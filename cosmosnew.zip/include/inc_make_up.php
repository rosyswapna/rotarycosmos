<div class="page_heading">
	<h7><?php echo $page_heading; ?></h7>
</div>
<div class="page_content">
	<?php echo $page_content; ?>
</div>

