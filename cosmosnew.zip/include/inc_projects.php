<div class="page_heading">
	<h7><?php echo $project_title; ?></h7>
</div>
<div class="page_content">
	<?php echo $project_content; ?>
</div>

