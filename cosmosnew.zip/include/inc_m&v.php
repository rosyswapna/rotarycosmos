            <div style="background-color:#0067A9; height:30px;border-top-left-radius:15px;border-top-right-radius:15px;padding-top:5px;">
                <h7>Mission and Vision</h7>
            </div>
            <div style="padding:10px;">
            <p><strong>OUR MISSION</strong><br />
Reaching out, touching and leaving a legacy of changed lives, both locally and abroad.</p>
             <p><strong>OUR VISION</strong><br />
               Contributing to our community,   our nation and our world by giving our future generations love and hope   through nurturing, educating and sharing.</p>
            </div>
