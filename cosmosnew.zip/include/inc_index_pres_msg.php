<h2>President's Message </h2>

    <?php echo $pres_msg_home ; ?> <a class="more" href="pres_msg.php" >more..</a>


