<ul class="sf-menu sf-js-enabled sf-shadow" id="menu">
<li><a href="/index.php">Home</a></li>
<li ><a  href="#" title="e-Club’s Column">Cosmos’s Column »</a>
<ul >
	<li ><a href="/pres_msg.php" title="Cochin Cosmos President’s Message">Club President’s Message</a></li>
	<li ><a href="/ri_pres_msg.php" title="RI President’s Corner">RI President’s Corner</a></li>
	<!--<li ><a href="#" title="Past President’s Message">Past President’s Message</a></li>-->
</ul>
</li>
<li ><a  href="#" title="About Cochin Cosmos">About Cochin Cosmos »</a>
<ul >
	<li><a href="/m&v.php" title="Mission and Vision">Mission and Vision</a></li>
	<!--<li ><a href="#" title="Cochin Cosmos The History">Cochin Cosmos The History</a></li>-->
	<!--<li ><a href="#" title="Cochin Cosmos Charter Certificate">Cochin Cosmos Charter Certificate</a></li>-->
	<li ><a href="/by_laws.php" title="Cochin Cosmos Bylaws">Bylaws</a></li>
	<li ><a href="#" title="Cochin Cosmos Constitution"> Constitution</a></li>
	<li ><a href="/faqs.php" title="Cochin Cosmos FAQs">FAQs</a></li>
	<li ><a href="/board_members.php" title="Cochin Cosmos Board Members">Board Members</a></li>
	<li ><a href="/member_class.php" title="Members Classification">Members Classification</a></li>
	<!--<li ><a href="#" title="Cochin CosmosCharter Members">Cochin CosmosCharter Members</a></li>-->
	<li ><a href="/clp.php" title="About CLP">About CLP</a></li>
	<li ><a href="/propose_member.php" title="How to propose a New Member">How to propose a New Member</a></li>
</ul>
</li>
<li ><a href="#" title="About Rotary">About Rotary »</a>
<ul >
	<!--<li ><a href="#" title="12 Steps to Rotary’s Centennial">12 Steps to Rotary’s Centennial</a></li>
	<li ><a href="#" title="General Materials">General Materials</a></li>-->
	<li ><a href="/membership.php" title="Membership">Membership</a></li>
	<!--<li ><a href="#" title="Presidential Citation">Presidential Citation</a></li>-->
	<li ><a href="/history.php" title="Rotary - A Brief History">Rotary - A Brief History</a></li>
	<li ><a href="/objects.php" title="Objects of Rotary">Objects of Rotary</a></li>
	<li ><a href="/4waytest.php" title="The 4-Way Test">The 4-Way Test</a></li>
</ul>
</li>
<li ><a href="/forum" title="Forum">Forum</a></li>
<li ><a  href="#" title="Events">Events »</a>
<ul >
	<li><a href="/photo_gallery.php"  title="Photo Gallery">Photo Gallery</a></li>
	<li ><a href="/video_gallery.php" title="What’s In The Headlines">What’s In The Headlines</a></li>
	<!--<li ><a href="#"  title="Website Archives">Website Archives</a></li>-->
</ul>
</li>
<li ><a class="sf-with-ul" href="#" title="Make Up">Attendance and Make up »</a>
<ul >
	<li ><a href="/make_up.php" title="Make Up Guidelines">Make Up Guidelines</a></li>
    <li ><a href="/signup.php" title="Guest Signup">Guest Signup</a></li>
</ul>
</li>
</ul>
