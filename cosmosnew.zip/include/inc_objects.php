
            <div style="background-color:#0067A9; height:30px;border-top-left-radius:15px;border-top-right-radius:15px;padding-top:5px;">
                <h7>Objects of Rotary</h7>
            </div>
            <div style="padding:10px;">
              <div>
                <p>The Object of Rotary is to encourage and foster the   ideal of service as a basis of worthy enterprise and, in particular, to   encourage and foster:</p>
                <p><strong>FIRST. </strong>The development of acquaintance as an opportunity for service;</p>
                <p><strong>SECOND. </strong>High   ethical standards in business and professions, the recognition of the   worthiness of all useful occupations, and the dignifying of each   Rotarian's occupation as an opportunity to serve society;</p>
                <p><strong>THIRD. </strong>The application of the ideal of service in each Rotarian's personal, business, and community life;</p>
                <p><strong>FOURTH. </strong>The   advancement of international understanding, goodwill, and peace through   a world fellowship of business and professional persons united in the   ideal of service. </p>
                <p>&nbsp;</p>
                <p>The mission of Rotary International , a worldwide   association of Rotary clubs, is to provide service to others, promote   high ethical standards, and advance world understanding , goodwill, and   peace through its fellowship of business, professional, and community   leaders. </p>
                <p>The Secretariat of Rotary International and The Rotary   Foundation (henceforth referred to as the &ldquo;Secretariat&rdquo;) is committed   to four core privacy principles. We believe strongly that adherence to   these principles of fair information practices is essential to our goal   of maintaining trust with our member clubs, Rotarians and other   individuals. </p>
                <p>The Secretariat supports approximately 1.2 million   Rotarians in over 200 countries and geographical areas. Rotary   International is organized at the club, district and international   levels to carry out its program of service. As part of its efforts to   assist clubs and districts and facilitate communication with Rotarians   and individuals about Rotary, the Secretariat collects sensitive and   personal information</p>
              </div>
              <p>&nbsp;</p>
</div>
