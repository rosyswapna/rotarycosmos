<?php

define("MEETING_DIR","images/meeting/");

?>
