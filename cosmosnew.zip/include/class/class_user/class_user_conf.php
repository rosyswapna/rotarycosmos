<?php

define("ADMINISTRATOR_DIR","images/administrator/");

?>
