<?php

define("GALLERY_DIR","images/gallery/");

?>
