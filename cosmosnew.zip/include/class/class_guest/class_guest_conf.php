<?php

define("GUEST_DIR","images/user/");

?>
