<?php

define("NEWS_DIR","images/gallery/");

?>
