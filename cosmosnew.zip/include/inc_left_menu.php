<div style="background-color:#0067A9; height:30px;border-top-left-radius:15px;border-top-right-radius:15px; padding-top:5px;">
	<h6>E-Club's Column</h6>
</div>
<ul>
	<li>RI President's Corner</li>
	<li>Club President's Message</li>
</ul>

