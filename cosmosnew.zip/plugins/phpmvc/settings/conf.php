<?php

$conf_page_caption = "Settings";

$conf_show_debug_window = "Show Debug Window";
$conf_enable_online_editting = "Enable Online Editing";

$conf_language = "Language";

$msg_update_success = "Settings successfully updated";

$msg_update_success_redirect_page = "settings.php";

$msg_update_failed = "Settings update failed";

$msg_update_failed_redirect_page = "settings.php";


$conf_submit_update = "Update";




?>
