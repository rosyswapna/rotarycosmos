<?php /* Smarty version Smarty-3.1.12, created on 2013-07-18 07:34:11
         compiled from "themes/default/main.tpl" */ ?>
<?php /*%%SmartyHeaderCode:165071539351c44ce0095b55-46414831%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '934b1a5b6d3f2b15d8c2c1176e983dee918f843c' => 
    array (
      0 => 'themes/default/main.tpl',
      1 => 1374132823,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '165071539351c44ce0095b55-46414831',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_51c44ce026ae24_48026552',
  'variables' => 
  array (
    'language_file' => 0,
    'subnav_location' => 0,
    'subnav_location_var' => 0,
    'page_title' => 0,
    'settings' => 0,
    'keywords' => 0,
    'mode' => 0,
    'THEMES_DIR' => 0,
    'theme' => 0,
    'top' => 0,
    'link_rel_first' => 0,
    'link_rel_prev' => 0,
    'link_rel_next' => 0,
    'link_rel_last' => 0,
    'tid' => 0,
    'user' => 0,
    'user_type' => 0,
    'rotary_menu' => 0,
    'admin' => 0,
    'menu' => 0,
    'item' => 0,
    'subtemplate' => 0,
    'content' => 0,
    'total_users_online' => 0,
    'total_postings' => 0,
    'total_threads' => 0,
    'registered_users' => 0,
    'registered_users_online' => 0,
    'unregistered_users_online' => 0,
    'forum_time_zone' => 0,
    'forum_time' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51c44ce026ae24_48026552')) {function content_51c44ce026ae24_48026552($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_replace')) include '/home/cosm123/public_html/forum/modules/smarty/plugins/modifier.replace.php';
?><?php  $_config = new Smarty_Internal_Config($_smarty_tpl->tpl_vars['language_file']->value, $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars("general", 'local'); ?><?php if ($_smarty_tpl->tpl_vars['subnav_location']->value&&$_smarty_tpl->tpl_vars['subnav_location_var']->value){?><?php $_smarty_tpl->tpl_vars["subnav_location"] = new Smarty_variable(smarty_modifier_replace($_smarty_tpl->getConfigVariable($_smarty_tpl->tpl_vars['subnav_location']->value),"[var]",$_smarty_tpl->tpl_vars['subnav_location_var']->value), null, 0);?><?php }elseif($_smarty_tpl->tpl_vars['subnav_location']->value){?><?php $_smarty_tpl->tpl_vars['subnav_location'] = new Smarty_variable($_smarty_tpl->getConfigVariable($_smarty_tpl->tpl_vars['subnav_location']->value), null, 0);?><?php }?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php if ($_smarty_tpl->tpl_vars['page_title']->value){?><?php echo $_smarty_tpl->tpl_vars['page_title']->value;?>
 - <?php }elseif($_smarty_tpl->tpl_vars['subnav_location']->value){?><?php echo $_smarty_tpl->tpl_vars['subnav_location']->value;?>
 - <?php }?><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['settings']->value['forum_name'], ENT_QUOTES, 'UTF-8', true);?>
</title>




<meta http-equiv="content-type" content="text/html; charset=<?php echo $_smarty_tpl->getConfigVariable('charset');?>
" />
<meta name="description" content="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['settings']->value['forum_description'], ENT_QUOTES, 'UTF-8', true);?>
" />
<?php if ($_smarty_tpl->tpl_vars['keywords']->value){?><meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['keywords']->value;?>
" /><?php }?>
<?php if ($_smarty_tpl->tpl_vars['mode']->value=='posting'){?>
<meta name="robots" content="noindex" />
<?php }?>
<meta name="generator" content="my little forum <?php echo $_smarty_tpl->tpl_vars['settings']->value['version'];?>
" />
<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['THEMES_DIR']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['theme']->value;?>
/style.min.css" media="all" />
<?php if ($_smarty_tpl->tpl_vars['settings']->value['rss_feed']==1){?><link rel="alternate" type="application/rss+xml" title="RSS" href="index.php?mode=rss" /><?php }?>
<?php if (!$_smarty_tpl->tpl_vars['top']->value){?>
<link rel="top" href="./" />
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['link_rel_first']->value){?>
<link rel="first" href="<?php echo $_smarty_tpl->tpl_vars['link_rel_first']->value;?>
" />
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['link_rel_prev']->value){?>
<link rel="prev" href="<?php echo $_smarty_tpl->tpl_vars['link_rel_prev']->value;?>
" />
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['link_rel_next']->value){?>
<link rel="next" href="<?php echo $_smarty_tpl->tpl_vars['link_rel_next']->value;?>
" />
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['link_rel_last']->value){?>
<link rel="last" href="<?php echo $_smarty_tpl->tpl_vars['link_rel_last']->value;?>
" />
<?php }?>
<link rel="search" href="index.php?mode=search" />
<link rel="shortcut icon" href="<?php echo $_smarty_tpl->tpl_vars['THEMES_DIR']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['theme']->value;?>
/../../../images/favicon.ico" />
<?php if ($_smarty_tpl->tpl_vars['mode']->value=='entry'){?><link rel="canonical" href="<?php echo $_smarty_tpl->tpl_vars['settings']->value['forum_address'];?>
index.php?mode=thread&amp;id=<?php echo $_smarty_tpl->tpl_vars['tid']->value;?>
" /><?php }?>
<script src="index.php?mode=js_defaults&amp;t=<?php echo $_smarty_tpl->tpl_vars['settings']->value['last_changes'];?>
<?php if ($_smarty_tpl->tpl_vars['user']->value){?>&amp;user_type=<?php echo $_smarty_tpl->tpl_vars['user_type']->value;?>
<?php }?>" type="text/javascript" charset="utf-8"></script>
<script src="js/main.min.js" type="text/javascript" charset="utf-8"></script>
<?php if ($_smarty_tpl->tpl_vars['mode']->value=='posting'){?>
<script src="js/posting.min.js" type="text/javascript" charset="utf-8"></script>
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['mode']->value=='admin'){?>
<script src="js/admin.min.js" type="text/javascript" charset="utf-8"></script>
<?php }?>














<link rel="shortcut icon" href="../../../images/layouts/default/favicon.ico" />
<link href="../../../css/default.css" rel="stylesheet" type="text/css" />
<link href="../../../css/sf_menu.css" rel="stylesheet" type="text/css" media="screen" />
<link rel="stylesheet" href="../../../css/orbit-1.2.3.css">

<script type="text/ecmascript" src="../../../js/jquery1.9.1/jquery-1.9.1.js"></script>
<script type="text/ecmascript" src="../../../js/superfish.js"></script>

<style type="text/css">
<!--
.style1 {
	color: #000099;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<div class="outer">
	<div class="inner">
    	<div class="header">
        	<div class="logo"><img src="../../../images/layouts/default/rilogo.png" /></div>
            <div class="name"><img src="../../../images/layouts/default/name.png" /></div>
            <div class="theme"><img src="../../../images/layouts/default/theme.png" border="1" /></div>
            <div class="contacts"> 
            	<!--Contact: 0484 xxx xxx <br />
                Email: mail@rotaryeclub.org-->
            </div>
            
            <div class="menu_container">
            	<div class="menu">
 <?php echo $_smarty_tpl->tpl_vars['rotary_menu']->value;?>


                </div>
            </div>
        </div>
        <div class="content">








<div id="top">

<div id="logo">
<!-- 
<?php if ($_smarty_tpl->tpl_vars['settings']->value['home_linkname']){?><p class="home"><a href="<?php echo $_smarty_tpl->tpl_vars['settings']->value['home_linkaddress'];?>
"><?php echo $_smarty_tpl->tpl_vars['settings']->value['home_linkname'];?>
</a></p><?php }?>
<h1><a href="./" title="<?php echo $_smarty_tpl->getConfigVariable('forum_index_link_title');?>
"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['settings']->value['forum_name'], ENT_QUOTES, 'UTF-8', true);?>
</a></h1>
-->
</div>

<div id="nav">
<ul id="usermenu">
<?php if ($_smarty_tpl->tpl_vars['user']->value){?><li><a href="/index.php" title="Home"><strong>Home</strong></a></li><li><a href="/forum" title="forum">Forum</a></li><?php if ($_smarty_tpl->tpl_vars['admin']->value){?><li><a href="index.php?mode=admin" title="<?php echo $_smarty_tpl->getConfigVariable('admin_area_link_title');?>
"><?php echo $_smarty_tpl->getConfigVariable('admin_area_link');?>
</a></li><?php }?><li><a href="/logout.php" title="<?php echo $_smarty_tpl->getConfigVariable('log_out_link_title');?>
"><?php echo $_smarty_tpl->getConfigVariable('log_out_link');?>
</a></li><?php }else{ ?><li><a href="/logout.php" title="<?php echo $_smarty_tpl->getConfigVariable('log_in_link_title');?>
"><?php echo $_smarty_tpl->getConfigVariable('log_in_link');?>
</a></li><?php if ($_smarty_tpl->tpl_vars['settings']->value['register_mode']!=2){?><li><a href="index.php?mode=register" title="<?php echo $_smarty_tpl->getConfigVariable('register_link_title');?>
"><?php echo $_smarty_tpl->getConfigVariable('register_link');?>
</a></li><?php }?><?php if ($_smarty_tpl->tpl_vars['settings']->value['user_area_public']){?><li><a href="index.php?mode=user" title="<?php echo $_smarty_tpl->getConfigVariable('user_area_link_title');?>
"><?php echo $_smarty_tpl->getConfigVariable('user_area_link');?>
</a></li><?php }?><?php }?>
<?php if ($_smarty_tpl->tpl_vars['menu']->value){?>
<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['menu']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?><li><a href="index.php?mode=page&amp;id=<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['linkname'];?>
</a></li><?php } ?>
<?php }?>
</ul>
<form id="topsearch" action="index.php" method="get" title="<?php echo $_smarty_tpl->getConfigVariable('search_title');?>
" accept-charset="<?php echo $_smarty_tpl->getConfigVariable('charset');?>
"><div><input type="hidden" name="mode" value="search" /><label for="search-input"><?php echo $_smarty_tpl->getConfigVariable('search_marking');?>
</label>&nbsp;<input id="search-input" type="text" name="search" value="<?php echo $_smarty_tpl->getConfigVariable('search_default_value');?>
" /><!--&nbsp;<input type="image" src="templates/<?php echo $_smarty_tpl->tpl_vars['settings']->value['template'];?>
/images/submit.png" alt="[&raquo;]" />--></div></form></div>
</div>

<div id="subnav">
<div id="subnav-1"><?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['theme']->value)."/subtemplates/subnavigation_1.inc.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
</div>
<div id="subnav-2"><?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['theme']->value)."/subtemplates/subnavigation_2.inc.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
</div>
</div>

<div id="content">
<?php if ($_smarty_tpl->tpl_vars['subtemplate']->value){?>
<?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['theme']->value)."/subtemplates/".((string)$_smarty_tpl->tpl_vars['subtemplate']->value), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }else{ ?>
<?php echo (($tmp = @$_smarty_tpl->tpl_vars['content']->value)===null||$tmp==='' ? '' : $tmp);?>

<?php }?>
</div>

<div id="footer">
<div id="footer-1"><?php if ($_smarty_tpl->tpl_vars['total_users_online']->value){?><?php echo smarty_modifier_replace(smarty_modifier_replace(smarty_modifier_replace(smarty_modifier_replace(smarty_modifier_replace(smarty_modifier_replace($_smarty_tpl->getConfigVariable('counter_users_online'),"[total_postings]",$_smarty_tpl->tpl_vars['total_postings']->value),"[total_threads]",$_smarty_tpl->tpl_vars['total_threads']->value),"[registered_users]",$_smarty_tpl->tpl_vars['registered_users']->value),"[total_users_online]",$_smarty_tpl->tpl_vars['total_users_online']->value),"[registered_users_online]",$_smarty_tpl->tpl_vars['registered_users_online']->value),"[unregistered_users_online]",$_smarty_tpl->tpl_vars['unregistered_users_online']->value);?>
<?php }else{ ?><?php echo smarty_modifier_replace(smarty_modifier_replace(smarty_modifier_replace($_smarty_tpl->getConfigVariable('counter'),"[total_postings]",$_smarty_tpl->tpl_vars['total_postings']->value),"[total_threads]",$_smarty_tpl->tpl_vars['total_threads']->value),"[registered_users]",$_smarty_tpl->tpl_vars['registered_users']->value);?>
<?php }?><br />
<?php if ($_smarty_tpl->tpl_vars['forum_time_zone']->value){?><?php echo smarty_modifier_replace(smarty_modifier_replace($_smarty_tpl->getConfigVariable('forum_time_with_time_zone'),'[time]',$_smarty_tpl->tpl_vars['forum_time']->value),'[time_zone]',$_smarty_tpl->tpl_vars['forum_time_zone']->value);?>
<?php }else{ ?><?php echo smarty_modifier_replace($_smarty_tpl->getConfigVariable('forum_time'),'[time]',$_smarty_tpl->tpl_vars['forum_time']->value);?>
<?php }?></div>
<div id="footer-2">
<ul id="footermenu">
<?php if ($_smarty_tpl->tpl_vars['settings']->value['rss_feed']==1){?><li><a class="rss" href="index.php?mode=rss" title="<?php echo $_smarty_tpl->getConfigVariable('rss_feed_postings_title');?>
"><?php echo $_smarty_tpl->getConfigVariable('rss_feed_postings');?>
</a> &nbsp;<a class="rss" href="index.php?mode=rss&amp;items=thread_starts" title="<?php echo $_smarty_tpl->getConfigVariable('rss_feed_new_threads_title');?>
"><?php echo $_smarty_tpl->getConfigVariable('rss_feed_new_threads');?>
</a></li><?php }?><li><a href="index.php?mode=contact" title="<?php echo $_smarty_tpl->getConfigVariable('contact_linktitle');?>
" rel="nofollow"><?php echo $_smarty_tpl->getConfigVariable('contact_link');?>
</a></li>
</ul></div>
</div>


<div id="pbmlf"><!-- <a href="http://mylittleforum.net/">powered by my little forum</a> --></div>

<!--[if IE]></div><![endif]-->

















       </div>
    </div>
    <div class="footer">
        <div class="footer_wrapper">
        	<table width="100%" border="0">
              <tr>
                <td width="50" rowspan="2" align="left" valign="middle"><!--<img src="../../../images/layouts/default/rilogo.png" width="50" />--></td>
                <td width="286" rowspan="2" align="left" valign="middle"><!--<span class="style1">Rotary International</span>--></td>
                <td width="650">
                <div class="menu_foo">
                    <div class="menu_item_foo">Home</a></div>
                    <div class="menu_item_foo">E-club's Column</a></div> 
                    <div class="menu_item_foo">About E-club</a></div> 
                    <div class="menu_item_foo">About Rotary</a></div> 
                    <div class="menu_item_foo">Forum</a></div> 
                    <div class="menu_item_foo">Events</a></div> 
                    <div class="menu_item_foo">Make Up</a></div>
                    <div class="menu_item_foo">Site Map</a></div>
                </div>                </td>
              </tr>
              <tr>
                <td align="right" valign="middle"> <img src="../../../images/layouts/default/fb1.png" width="24" /> &nbsp; <img src="../../../images/layouts/default/twitter.png" width="24" /> &nbsp; <img src="../../../images/layouts/default/ut.png" width="24" /></td>
              </tr>
              <tr>
                <td colspan="2"><div class="foo_col1">Copyright © Rotary eClub. All Rights Reserved.</div></td>
                <td><div class="foo_col2">Contact Us | Privacy Policy | Terms of Use</div></td>
              </tr>
            </table>

        </div>
    </div>
</div>
</body>
</html>
<?php }} ?>