<?php /* Smarty version Smarty-3.1.12, created on 2013-06-21 12:53:53
         compiled from "themes/default/ajax_preview.tpl" */ ?>
<?php /*%%SmartyHeaderCode:94962708751c44ce12a8d31-36010524%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c3ae5fb760f1f0c087d5c4b0e0becd2149e92e61' => 
    array (
      0 => 'themes/default/ajax_preview.tpl',
      1 => 1370532434,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '94962708751c44ce12a8d31-36010524',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'THEMES_DIR' => 0,
    'theme' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_51c44ce12cdd68_15733326',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51c44ce12cdd68_15733326')) {function content_51c44ce12cdd68_15733326($_smarty_tpl) {?><div id="ajax-preview-top"></div>
<div id="ajax-preview-main">
 <div id="ajax-preview-body">
  <img id="ajax-preview-close" src="<?php echo $_smarty_tpl->tpl_vars['THEMES_DIR']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['theme']->value;?>
/images/close.png" alt="[x]" title="<?php echo $_smarty_tpl->getConfigVariable('close');?>
" />
  <div id="ajax-preview-content"></div>
 </div>
</div>
<?php }} ?>