<?php /* Smarty version Smarty-3.1.12, created on 2013-07-12 13:23:20
         compiled from "themes/default/rss.tpl" */ ?>
<?php /*%%SmartyHeaderCode:131820181851e0034897ead6-60603058%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3f4c8824057bcd34cdaa5b634db705adafda9cea' => 
    array (
      0 => 'themes/default/rss.tpl',
      1 => 1370532436,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '131820181851e0034897ead6-60603058',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'settings' => 0,
    'thread_starts' => 0,
    'thread' => 0,
    'rss_items' => 0,
    'replies' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_51e00348a63977_95055526',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51e00348a63977_95055526')) {function content_51e00348a63977_95055526($_smarty_tpl) {?><?php  $_config = new Smarty_Internal_Config($_smarty_tpl->tpl_vars['settings']->value['language_file'], $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars("general", 'local'); ?><?php echo '<?xml';?> version="1.0" encoding="<?php echo $_smarty_tpl->getConfigVariable('charset');?>
"<?php echo '?>';?>
<rss version="2.0" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:dc="http://purl.org/dc/elements/1.1/"<?php if ($_smarty_tpl->tpl_vars['thread_starts']->value){?> xmlns:wfw="http://wellformedweb.org/CommentAPI/"<?php }?>>
<channel>
<title><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['settings']->value['forum_name'], ENT_QUOTES, 'UTF-8', true);?>
<?php if ($_smarty_tpl->tpl_vars['thread']->value&&$_smarty_tpl->tpl_vars['rss_items']->value[0]['title']){?> - <?php echo $_smarty_tpl->tpl_vars['rss_items']->value[0]['title'];?>
<?php }?></title>
<link><?php echo $_smarty_tpl->tpl_vars['settings']->value['forum_address'];?>
</link>
<description><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['settings']->value['forum_description'], ENT_QUOTES, 'UTF-8', true);?>
</description>
<language><?php echo $_smarty_tpl->getConfigVariable('language');?>
</language>
<?php if ($_smarty_tpl->tpl_vars['rss_items']->value){?>
<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['rss_items']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
<item>
<title><?php if ($_smarty_tpl->tpl_vars['replies']->value){?><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
: <?php }?><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
<?php if ($_smarty_tpl->tpl_vars['item']->value['reply']&&!$_smarty_tpl->tpl_vars['replies']->value){?> <?php echo $_smarty_tpl->getConfigVariable('rss_reply_marking');?>
<?php }?></title>
<content:encoded><![CDATA[<?php if ($_smarty_tpl->tpl_vars['item']->value['text']!=''){?><?php echo $_smarty_tpl->tpl_vars['item']->value['text'];?>
<?php }else{ ?><?php echo $_smarty_tpl->getConfigVariable('no_text');?>
<?php }?>]]></content:encoded>
<link><?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
</link>
<guid><?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
</guid>
<pubDate><?php echo $_smarty_tpl->tpl_vars['item']->value['pubdate'];?>
</pubDate>
<?php if ($_smarty_tpl->tpl_vars['item']->value['category']){?><category><?php echo $_smarty_tpl->tpl_vars['item']->value['category'];?>
</category><?php }?>
<?php if ($_smarty_tpl->tpl_vars['thread_starts']->value){?><wfw:commentRss><?php echo $_smarty_tpl->tpl_vars['item']->value['commentRss'];?>
</wfw:commentRss><?php }?>
<dc:creator><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</dc:creator>
</item>
<?php } ?>
<?php }?>
</channel>
</rss>
<?php }} ?>