<?php /* Smarty version Smarty-3.1.12, created on 2013-06-21 14:26:00
         compiled from "themes/default/subtemplates/login_pw_forgotten.inc.tpl" */ ?>
<?php /*%%SmartyHeaderCode:183573407251c4627856f902-02571283%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a5de5da45f0fac1c25a50005e46003658dc0ee47' => 
    array (
      0 => 'themes/default/subtemplates/login_pw_forgotten.inc.tpl',
      1 => 1370532436,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '183573407251c4627856f902-02571283',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'language_file' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_51c462785d5947_05408725',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51c462785d5947_05408725')) {function content_51c462785d5947_05408725($_smarty_tpl) {?><?php  $_config = new Smarty_Internal_Config($_smarty_tpl->tpl_vars['language_file']->value, $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars("pw_forgotten", 'local'); ?>
<p><?php echo $_smarty_tpl->getConfigVariable('pw_forgotten_exp');?>
</p>
<form action="index.php" method="post" accept-charset="<?php echo $_smarty_tpl->getConfigVariable('charset');?>
">
<div>
<input type="hidden" name="mode" value="login" />
<p><label for="pwf_email" class="main"><?php echo $_smarty_tpl->getConfigVariable('pwf_email');?>
</label><br />
<input id="pwf_email" type="text" name="pwf_email" size="30" /> <input type="submit" name="pwf_submit" value="<?php echo $_smarty_tpl->getConfigVariable('submit_button_ok');?>
" /></p>
</div>
</form>
<?php }} ?>